import { useState, useEffect, useRef } from 'react';
import { 
  Home, 
  Newspaper, 
  Landmark, 
  TrendingUp, 
  Trophy, 
  Heart, 
  Bell, 
  Puzzle, 
  Globe, 
  PlayCircle, 
  MessageSquare, 
  Send, 
  Circle, 
  ChevronRight, 
  MapPin, 
  Phone, 
  Mail, 
  Facebook, 
  Twitter, 
  Youtube,
  LogIn,
  UserPlus,
  Play,
  Quote
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [tickerSpeed, setTickerSpeed] = useState(30);
  const [chatMessages, setChatMessages] = useState([
    { user: 'John', text: 'Great coverage of Masaza Cup!' },
    { user: 'Sarah', text: 'Buddu looking strong this year' },
    { user: 'Mike', text: 'Live from Masaka!' },
    { user: 'Jane', text: 'Go Ssingo!' },
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const users = ['Fan12', 'MasakaFan', 'WakisoRes', 'SportsLover', 'NewsWatcher'];
      const texts = [
        'Great match today!',
        'Buddu is unstoppable!',
        'Love the coverage SSAZA TV',
        'What time is the next game?',
        'Go Ssingo! 💪',
        'Live from Masaka 🔥',
        'Best tournament ever!',
        'Airtel bundles are working great'
      ];
      const newUser = users[Math.floor(Math.random() * users.length)];
      const newText = texts[Math.floor(Math.random() * texts.length)];
      
      setChatMessages(prev => [...prev.slice(-19), { user: newUser, text: newText }]);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  return (
    <div className="min-h-screen bg-[#f0f2f5] text-[#1e1e1e] font-sans">
      {/* Header */}
      <header className="bg-linear-to-br from-[#c41e3a] to-[#8b0000] text-white p-4 flex flex-col md:flex-row items-center justify-between border-b-3 border-[#ffd700] gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center border-3 border-[#ffd700] overflow-hidden">
            <img src="https://drive.google.com/uc?export=view&id=1xVeh5lL-YHgcgST5QDO8Rlz28qAZGvNs" alt="SSAZA TV Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <div className="text-center md:text-left">
            <h1 className="text-3xl font-extrabold tracking-wider">SSAZA TV</h1>
            <p className="text-sm italic text-[#ffd700]">#Agaliwo</p>
          </div>
        </div>
        
        <div className="hidden lg:flex items-center bg-white/20 px-4 py-2 rounded-full border-l-4 border-[#ffd700]">
          <Quote className="w-4 h-4 mr-2" />
          <span className="text-lg font-semibold">Y'OMUNTU WABULIJJO</span>
          <Quote className="w-4 h-4 ml-2 rotate-180" />
        </div>

        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 bg-white text-[#c41e3a] px-4 py-2 rounded-lg font-bold hover:bg-[#ffd700] transition-colors shadow-md">
            <LogIn className="w-4 h-4" />
            Login
          </button>
          <button className="flex items-center gap-2 bg-[#ffd700] text-[#1a1a1a] px-4 py-2 rounded-lg font-bold hover:bg-white transition-colors shadow-md">
            <UserPlus className="w-4 h-4" />
            Signup
          </button>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-[#2c3e50] p-3 sticky top-0 z-50 shadow-lg overflow-x-auto">
        <ul className="flex items-center gap-6 whitespace-nowrap max-w-7xl mx-auto px-4">
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Home className="w-4 h-4" /> Home</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Newspaper className="w-4 h-4" /> News</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Landmark className="w-4 h-4" /> Politics</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Business</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Trophy className="w-4 h-4" /> Sports</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Heart className="w-4 h-4" /> Lifestyle</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Bell className="w-4 h-4" /> Alerts</a></li>
          <li><a href="#" className="text-white hover:bg-[#c41e3a] px-3 py-2 rounded-md transition-all flex items-center gap-2"><Globe className="w-4 h-4" /> World</a></li>
        </ul>
      </nav>

      {/* Breaking News Ticker */}
      <div className="bg-[#1a1a1a] text-white p-2 flex flex-col sm:flex-row items-center gap-4 border-b-2 border-[#c41e3a]">
        <span className="bg-[#c41e3a] px-4 py-1 rounded-full font-bold text-sm uppercase whitespace-nowrap animate-pulse">BREAKING</span>
        <div className="flex-1 overflow-hidden bg-[#111] rounded-full py-1 relative h-8">
          <div 
            className="whitespace-nowrap absolute"
            style={{ 
              animation: `ticker ${tickerSpeed}s linear infinite`,
              paddingLeft: '100%'
            }}
          >
            <strong>LIVE:</strong> Masaza Cup 2026 officially launched at Bulange • Bobi Wine addresses nation from hiding • Chagos Islands dispute escalates • Airtel launches special Masaza Cup bundles • Uganda Cranes ready for AFCON qualifiers • Katikkiro meets with Masaza teams • 
          </div>
        </div>
        <div className="flex items-center gap-2 bg-[#2a2a2a] px-3 py-1 rounded-full border border-[#ffd700] text-[#ffd700]">
          <TrendingUp className="w-3 h-3" />
          <input 
            type="range" 
            min="5" 
            max="60" 
            value={tickerSpeed} 
            onChange={(e) => setTickerSpeed(Number(e.target.value))}
            className="w-24 accent-[#c41e3a] cursor-pointer"
          />
          <span className="text-xs font-bold text-white w-8">{tickerSpeed}s</span>
        </div>
      </div>

      {/* Live Player Section */}
      <section className="p-4 md:p-8 bg-linear-to-r from-[#000428] to-[#004e92]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 bg-black/50 p-6 rounded-2xl border border-[#ffd700]">
          <div className="lg:col-span-2 relative">
            <div className="absolute top-4 left-4 bg-[#c41e3a] text-white px-4 py-1 rounded-full font-bold flex items-center gap-2 z-10 animate-pulse">
              <Circle className="w-3 h-3 fill-current" /> LIVE NOW
            </div>
            <div className="aspect-video bg-black rounded-xl overflow-hidden border-3 border-[#ffd700]">
              <iframe 
                src="https://www.youtube.com/embed/live_stream?channel=YOUR_CHANNEL_ID" 
                className="w-full h-full"
                allowFullScreen
              />
            </div>
            <div className="mt-4 text-white">
              <h3 className="text-xl font-bold flex items-center gap-2"><PlayCircle className="w-6 h-6 text-[#c41e3a]" /> SSAZA TV Live Broadcast</h3>
              <p className="text-gray-300">Watch our 24/7 news coverage and updates from across Uganda</p>
            </div>
          </div>
          
          <div className="bg-[#1a1a2e] rounded-xl p-4 border border-[#ffd700] flex flex-col h-[400px] lg:h-auto">
            <div className="flex justify-between items-center border-b border-[#ffd700] pb-2 mb-4">
              <span className="text-white font-bold flex items-center gap-2"><MessageSquare className="w-5 h-5" /> Live Chat</span>
              <span className="bg-[#ffd700] text-black px-2 py-0.5 rounded text-xs font-bold">2,847 watching</span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2 bg-[#16213e] p-3 rounded-lg custom-scrollbar">
              {chatMessages.map((msg, i) => (
                <div key={i} className="text-sm">
                  <span className="font-bold text-[#ffd700]">{msg.user}: </span>
                  <span className="text-white">{msg.text}</span>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
            <div className="mt-4 flex gap-2">
              <input 
                type="text" 
                placeholder="Join the conversation..." 
                className="flex-1 bg-white/10 text-white px-3 py-2 rounded-lg border-none focus:ring-2 focus:ring-[#c41e3a] outline-none"
              />
              <button className="bg-[#c41e3a] text-white p-2 rounded-lg hover:bg-[#8b0000] transition-colors">
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Tournament Section */}
          <section className="bg-white rounded-2xl p-6 shadow-xl border-t-4 border-[#c41e3a]">
            <h2 className="text-2xl font-bold text-[#c41e3a] mb-6 flex items-center gap-3 border-b-2 border-[#ffd700] pb-2">
              <Trophy className="w-8 h-8" /> Buganda Kingdom Masaza Cup 2026
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              {['BULANGE', 'MASENGERE', 'MUGANZIRWAZZA'].map((group, i) => (
                <div key={group} className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                  <div className="bg-[#c41e3a] text-white text-center py-1 rounded-md font-bold mb-3">GROUP {String.fromCharCode(65 + i)} - {group}</div>
                  <ul className="text-sm space-y-1">
                    {i === 0 && ['Buddu', 'Buluuli', 'Busiro', 'Busujju', 'Gomba', 'Ssese'].map(t => <li key={t} className="flex justify-between border-b border-gray-100 pb-1"><span>{t}</span></li>)}
                    {i === 1 && ['Bugerere', 'Bulemeezi', 'Buvuma', 'Buweekula', 'Kyaddondo', 'Mawokota'].map(t => <li key={t} className="flex justify-between border-b border-gray-100 pb-1"><span>{t}</span></li>)}
                    {i === 2 && ['Butambala', 'Kabula', 'Kkooki', 'Kyaggwe', 'Mawogola', 'Ssingo'].map(t => <li key={t} className="flex justify-between border-b border-gray-100 pb-1"><span>{t}</span></li>)}
                  </ul>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              {['Teams', 'Groups', 'Fixtures', 'Results', 'Players', 'Stats'].map(btn => (
                <button key={btn} className="bg-[#c41e3a] text-white px-4 py-1.5 rounded-md text-sm font-semibold hover:bg-[#8b0000] transition-colors">{btn}</button>
              ))}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#2c3e50] text-white">
                    <th className="p-3">Team</th>
                    <th className="p-3">GP</th>
                    <th className="p-3">W</th>
                    <th className="p-3">D</th>
                    <th className="p-3">L</th>
                    <th className="p-3">GD</th>
                    <th className="p-3">P</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="bg-[#ffd700] font-bold">
                    <td className="p-3">Buluuli</td><td className="p-3">10</td><td className="p-3">5</td><td className="p-3">4</td><td className="p-3">1</td><td className="p-3">+7</td><td className="p-3">19</td>
                  </tr>
                  <tr className="bg-gray-100">
                    <td className="p-3">Busujju</td><td className="p-3">10</td><td className="p-3">5</td><td className="p-3">3</td><td className="p-3">2</td><td className="p-3">+3</td><td className="p-3">18</td>
                  </tr>
                  <tr>
                    <td className="p-3">Ssese</td><td className="p-3">10</td><td className="p-3">6</td><td className="p-3">0</td><td className="p-3">4</td><td className="p-3">+2</td><td className="p-3">18</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* News Grid */}
          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-[#c41e3a] flex items-center gap-3 border-b-2 border-[#ffd700] pb-2">
              <Newspaper className="w-8 h-8" /> Latest News
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { title: "Buddu Edge Gomba 1-0 in Opener", cat: "Sports", img: "https://picsum.photos/seed/sports/800/600" },
                { title: "Katikkiro Mayiga Launches Cup", cat: "Tournament", img: "https://picsum.photos/seed/king/800/600" },
                { title: "Airtel Launches New Bundles", cat: "Business", img: "https://picsum.photos/seed/tech/800/600" },
                { title: "Bobi Wine Addresses Nation", cat: "Politics", img: "https://picsum.photos/seed/politics/800/600" },
              ].map((news, i) => (
                <motion.div 
                  key={i}
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-xl overflow-hidden shadow-lg group cursor-pointer"
                >
                  <div className="h-48 relative overflow-hidden">
                    <img src={news.img} alt={news.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
                    <span className="absolute top-3 left-3 bg-[#c41e3a] text-white px-3 py-1 rounded-full text-xs font-bold">{news.cat}</span>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-2 group-hover:text-[#c41e3a] transition-colors">{news.title}</h3>
                    <p className="text-sm text-gray-600 line-clamp-2">Latest updates from the ground as the event unfolds with massive attendance...</p>
                    <div className="mt-4 flex items-center text-xs text-gray-400 gap-4">
                      <span className="flex items-center gap-1"><Circle className="w-2 h-2 fill-current" /> 2h ago</span>
                      <span>Kampala</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-8">
          <div className="bg-white rounded-2xl p-6 shadow-xl border-l-4 border-[#ffd700]">
            <h3 className="text-xl font-bold text-[#c41e3a] mb-4 flex items-center gap-2"><TrendingUp className="w-5 h-5" /> Trending</h3>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map(n => (
                <div key={n} className="flex gap-4 items-center border-b border-gray-100 pb-3 last:border-0">
                  <span className="w-6 h-6 bg-[#c41e3a] text-white rounded-full flex items-center justify-center text-xs font-bold shrink-0">{n}</span>
                  <div>
                    <p className="text-sm font-bold leading-tight">Major updates on the Masaza Cup 2026 fixtures...</p>
                    <span className="text-xs text-gray-400">12K shares</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-linear-to-br from-[#c41e3a] to-[#8b0000] text-white rounded-2xl p-6 shadow-xl text-center">
            <Bell className="w-12 h-12 mx-auto mb-4 text-[#ffd700]" />
            <h4 className="text-xl font-bold mb-2">Get News Alerts</h4>
            <p className="text-sm text-white/80 mb-4">Subscribe for instant alerts on breaking news</p>
            <input type="email" placeholder="Your email" className="w-full bg-white/20 border-none rounded-lg px-4 py-2 mb-3 placeholder:text-white/50 outline-none focus:ring-2 focus:ring-[#ffd700]" />
            <button className="w-full bg-[#ffd700] text-black font-bold py-2 rounded-lg hover:bg-white transition-colors">Subscribe</button>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-xl">
            <h3 className="text-xl font-bold text-[#c41e3a] mb-4 flex items-center gap-2"><Puzzle className="w-5 h-5" /> Puzzles</h3>
            <div className="aspect-square bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300">
              <p className="text-gray-400 text-sm">Daily Crossword Loading...</p>
            </div>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="bg-[#1a1a1a] text-white pt-12 pb-6 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-white rounded-full p-1">
                <img src="https://drive.google.com/uc?export=view&id=1xVeh5lL-YHgcgST5QDO8Rlz28qAZGvNs" alt="Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
              </div>
              <h3 className="text-xl font-bold text-[#ffd700]">SSAZA TV</h3>
            </div>
            <p className="text-sm text-gray-400 mb-6">Y'OMUNTU WABULIJJO - Uganda's Premier Broadcast Network serving with truth and integrity.</p>
            <div className="flex gap-3">
              {[Facebook, Twitter, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 bg-[#c41e3a] rounded-full flex items-center justify-center hover:bg-[#ffd700] hover:text-black transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-[#ffd700] font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              {['Home', 'About Us', 'News', 'Politics', 'Sports', 'Contact'].map(link => (
                <li key={link} className="flex items-center gap-2 hover:text-[#ffd700] cursor-pointer transition-colors">
                  <ChevronRight className="w-4 h-4" /> {link}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#ffd700] font-bold mb-4">Categories</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              {['Breaking News', 'Business', 'Entertainment', 'Lifestyle', 'Weather'].map(cat => (
                <li key={cat} className="hover:text-[#ffd700] cursor-pointer transition-colors">{cat}</li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#ffd700] font-bold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start gap-3"><MapPin className="w-5 h-5 text-[#c41e3a] shrink-0" /> Plot 24, Lumumba Avenue, Kampala, Uganda</li>
              <li className="flex items-center gap-3"><Phone className="w-5 h-5 text-[#c41e3a] shrink-0" /> +256 200 999 594</li>
              <li className="flex items-center gap-3"><Mail className="w-5 h-5 text-[#c41e3a] shrink-0" /> info@ssazatv.ug</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto pt-6 border-t border-white/10 text-center text-xs text-gray-500">
          <p>&copy; 2026 SSAZA TV. All rights reserved. | Serving Uganda with Truth & Integrity</p>
        </div>
      </footer>

      <style>{`
        @keyframes ticker {
          0% { transform: translateX(0); }
          100% { transform: translateX(-100%); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255,255,255,0.05);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #c41e3a;
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
}
